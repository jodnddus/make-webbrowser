package Main;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

public class ServerThread implements Runnable{
	public Socket socket;
	private PrintWriter printwriter = null;
	
	public ServerThread(Socket socket) {
		this.socket = socket;
	}
	
	public PrintWriter getPrintWriter() {
		return printwriter;
	}
	
	@Override
	public void run() {
		
		BufferedReader bufferedreader = null;
		
		try {
			bufferedreader = new BufferedReader(new InputStreamReader(socket.getInputStream(), "UTF-8"));
			printwriter = new PrintWriter(socket.getOutputStream(), true);
			
			while(true) {
				String str = bufferedreader.readLine();
				if(str==null) {
					break;
				}
				
				if(str.equals("memberdata")) { 
					printwriter.println("command//!"+ServerControl._getInetAddress());
				} else {
					ServerControl.println(str, socket.getInetAddress().toString(), this);
				}
				System.out.println(str);
			}
		} catch (IOException e) {
            e.printStackTrace();
		}
		finally {
			ServerControl.remove(this);
		}
	}
}
