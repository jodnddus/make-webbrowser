package Main;

import java.util.ArrayList;

public class ServerControl {
	
	public static ArrayList<ServerThread> arraylist = new ArrayList<ServerThread>();
	
	public static void add(ServerThread thread) {
		arraylist.add(thread);
	}
	
	public static void println(String message, String inetAddress, ServerThread serverthread) {
		for(ServerThread thread : arraylist)
			if(serverthread != thread) thread.getPrintWriter().println(message+" "+inetAddress);
	}
	
	public static void remove(ServerThread thread) {
		arraylist.remove(thread);
		System.out.println("[Server] "+thread.socket.getInetAddress()+"���� ������.");
	}
	
	public static String _getInetAddress() {
		String str = "";
		for(ServerThread thread : arraylist) {
			str += thread.socket.getInetAddress();
			str += ",";
		}
		return str;
	}
}
