package Main;

import java.io.IOException;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;
import java.lang.NullPointerException;

public class BubbleServer { // TODO 
	static int port = 0;
	
	static{
		try {
			System.out.println("서버 IP : "+InetAddress.getLocalHost().getHostAddress());
			System.out.print("포트를 입력해주세요. 권장 포트는 4444 입니다. : ");
			//do-while TODO
			while(port <= 1000 || port >= 19132) {
				@SuppressWarnings("resource")
				Scanner scanner = new Scanner(System.in);
				port = scanner.nextInt();
			}
		} catch (UnknownHostException e) {
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) {
		
		ServerSocket serversocket = null;
		System.out.println("[Server] Server started");
		
		try {
			serversocket = new ServerSocket(port);
			while(true) {
				Socket socket = serversocket.accept();
				
				if(socket != null) {
					System.out.println("[Server] "+socket.getInetAddress()+"연결됨.");
					ServerThread serverThread = new ServerThread(socket);
                    Thread thread = new Thread(serverThread);
                    thread.start();
                    ServerControl.add(serverThread);
				}
			}
		} catch (IOException e){
			e.printStackTrace();  
		} catch (NullPointerException e) { 
			System.out.println("[Server] Socket error");
			e.printStackTrace();
		}
		
	}
}
