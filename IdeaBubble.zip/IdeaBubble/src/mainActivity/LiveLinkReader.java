package mainActivity;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.Socket;
 
public class LiveLinkReader{
	
    private Socket socket;
    BufferedReader bufferedReader = null;
    PrintWriter printWriter = null;
    
    public LiveLinkReader(Socket socket) throws IOException {
        this.socket = socket;
        //bufferedReader = new BufferedReader(new InputStreamReader(System.in, "euc-kr")); // 생성자 제2 PRMT "UTF-8"
        printWriter = new PrintWriter(socket.getOutputStream(), true);
    }
    
    public void sendData(String data) throws IOException {
    		try {
    			String str = data;//bufferedReader.readLine();
    			printWriter.println(str);
    		}catch(Exception e) {
            if(printWriter != null){
                printWriter.close();
            }
            if(socket != null){
                try {
                    socket.close();
                } catch (IOException d) {
                    // TODO Auto-generated catch block
                    d.printStackTrace();
                }
            } 
    		}//예외 처리 
    }
}
