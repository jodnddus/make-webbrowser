package mainActivity;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.concurrent.Worker;
import javafx.concurrent.Worker.State;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Group;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.control.TabPane.TabClosingPolicy;
import javafx.scene.control.TextField;
import javafx.scene.control.ToolBar;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import javafx.scene.layout.HBox;
import javafx.scene.text.Font;
import javafx.scene.text.TextAlignment;
import javafx.scene.text.FontSmoothingType;
import javafx.scene.web.WebEngine;
import javafx.scene.web.WebView;
import javafx.stage.Stage;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.InetAddress;
import java.net.Socket;
import java.net.URL;
//import java.util.List;
import java.net.UnknownHostException;

import org.controlsfx.control.PopOver;
import org.controlsfx.control.PopOver.ArrowLocation;

public class IdeaBubble extends Application {
	private final String TABPANE_ID = "tab-pane";
	private final String TAB_ID = "main_tab";
	private final String TEXTBOX_ID = "mtextbox";
	private final String WEBVIEW_ID = "main_web";
	
  public static String browserLocation = "";
  private URL main_url;
  public static TabPane tabPane = new TabPane();
  private static String shareURL = "";
  private static boolean connectStatus = false;
  private Socket socket = null;
  private LiveLinkReader input_reader = null;
  private BubbleClient base_client = null;
  private static Button BubbleButton = new Button();
  private Button Member = new Button();
  public static String INPUT_STRING = "";
  
  StackPane root = new StackPane();

  public static void main(String[] args) {
	  //System.setProperty ( "apple.laf.useScreenMenuBar", "true");
	  //System.setProperty ( "com.apple.mrj.application.apple.menu.about.name", "IdeaBubble");
	  //System.setProperty("headless.geometry", "1600x1200-32");
	  //System.setProperty("prism.order", "sw");
	    launch(args);
  }
  
  @Override
  public void start(final Stage stage) {
	  stage.setTitle("IdeaBUBBLE");
	  stage.getIcons().add(new Image(this.getClass().getResourceAsStream("icon.png")));
	  //System.setProperty("prism.lcdtext", "true");
	  
	  //stage.setHeight(java.awt.Toolkit.getDefaultToolkit().getScreenSize().height);
	  //stage.setWidth(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width);
	  
	  stage.setHeight(java.awt.Toolkit.getDefaultToolkit().getScreenSize().height);
	  stage.setWidth(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width);
	  
	  main_url = this.getClass().getResource("mainPage.html");
	  System.out.println("main_url : "+main_url);//시작페이지 불러오기 
	  
      VBox root2 = new VBox();
     
     
      tabPane.setId(TABPANE_ID);
      tabPane.setTabClosingPolicy(TabClosingPolicy.ALL_TABS);
      
      Tab newTabTab = new Tab();
      newTabTab.setClosable(false);
      Label addLabel = new Label("\u2795");
      addLabel.setId("addLabel");
      //addLabel.setStyle("-fx-alignment : center; -fx-content-display: center");
      addLabel.setOnMouseClicked((EventHandler<? super MouseEvent>) new EventHandler<MouseEvent>() {
          @Override
          public void handle(MouseEvent paramT) {
              System.out.println("mouse click");
              Tab tmp = _getTab(main_url.toString());
      	  	tabPane.getTabs().add(tmp);
      	  	tabPane.getSelectionModel().select(tmp);
          }
      });
     //newTabTab.setStyle("-fx-pref-width: 50");
      newTabTab.setGraphic(addLabel);
      newTabTab.setId("newtab");
      newTabTab.setDisable(true);
      tabPane.getTabs().add(newTabTab);
      
      Tab firstTab = _getTab(main_url.toString());
      tabPane.getTabs().add(firstTab); //Initialize first tab
      tabPane.getSelectionModel().select(firstTab);
      
      BubbleButton.setOnAction((ActionEvent event) -> {
  	  	try {
			sendData();
		} catch (IOException e) {
				// TODO Auto-generated catch block
			e.printStackTrace();
		}
      });
      
      BubbleButton.setStyle("-fx-background-color : transparent;");
      //BubbleButton.setPrefSize(70, 70);
      ImageView imageView = new ImageView(new Image(this.getClass().getResourceAsStream("img/BubbleButton.png"))); // TODO Image Size FILLLLLLL!!!!
	  imageView.setFitHeight(80);
	  imageView.setFitWidth(80);
	  BubbleButton.setPrefSize(10, 10);
	  BubbleButton.setGraphic(imageView);
      root.setAlignment(BubbleButton, Pos.BOTTOM_CENTER);
      
      Member.setGraphic(_getImageView(this.getClass().getResourceAsStream("img/member.png")));
	  Member.setOnAction((ActionEvent event) -> {
	  		try {
	  			getMemberData();
	  		} catch (IOException e) {
	  			e.printStackTrace();
	  		}
	  });
      
      /*PopOver popovera = new PopOver(); 
      popovera.setId("aa");
      TextField campo = new TextField();      
      popovera.setContentNode(campo);
      Button btn = new Button();
      btn.setText("Abrir PopOver");
      btn.setId("btn");
      btn.setOnAction((ActionEvent event) -> {          
          //popovera.show(btn);
          //stage.setScene(scene2);
          //((Parent) popover.getSkin().getNode()).getStylesheets()
              //.add(getClass().getResource("PopOver.css").toExternalForm());                   
      });     
      root.getChildren().add(btn); */
      
      root.getChildren().add(tabPane);
      root.getChildren().add(BubbleButton);
      
      
      Scene scene = new Scene(root); scene.getStylesheets().add(getClass().getResource("skin.css").toExternalForm());
      
      stage.setScene(scene); 
     
      stage.show();
      //webView.setZoom(2.2); //2.2배 Zoom
  }

  private Tab _getTab(String BrowserLoc) {
	  Tab _tab = new Tab("Welcome!");
	  VBox inBox = new VBox();
	  WebView webView = new WebView();
	  WebEngine webEngine = webView.getEngine();
	  TextField mTextbox = new TextField();
	  ToolBar mToolbar = new ToolBar();  
	  Label zoom_rate = new Label();
	  
	  Button back = new Button();
	  back.setGraphic(_getImageView(this.getClass().getResourceAsStream("img/back.png")));
	  
	  Button forward = new Button();
	  forward.setGraphic(_getImageView(this.getClass().getResourceAsStream("img/forward.png")));
	  
	  Button refresh = new Button();
	  refresh.setGraphic(_getImageView(this.getClass().getResourceAsStream("img/refresh.png")));
	  
	  Button goHome = new Button();
	  goHome.setGraphic(_getImageView(this.getClass().getResourceAsStream("img/home.png")));
	  
	  Button zoomIN = new Button();
	  zoomIN.setGraphic(_getImageView(this.getClass().getResourceAsStream("img/zoomin.png")));
	  
	  Button zoomOUT = new Button();
	  zoomOUT.setGraphic(_getImageView(this.getClass().getResourceAsStream("img/zoomout.png")));
	 
	  Button connect = new Button();
	  connect.setGraphic(_getImageView(this.getClass().getResourceAsStream("img/connect.png")));
	  
	  mToolbar.setStyle("-fx-background-color: #f2f2f2");
	  mTextbox.setStyle("-fx-pref-width: 1000px;");
	  
	  _tab.setId(TAB_ID);
	  _tab.setStyle("-fx-pref-width: 144");
	  
	  mTextbox.setId(TEXTBOX_ID);
	  
      zoom_rate.setText("x1.0");
	  
	  //---------- WebView AREA ----------
	  
	  /* if str에 http://(반려) www(우선) 없을 시 추가해서 링크로 넘기도록*/
      
      webView.setPrefSize(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width, java.awt.Toolkit.getDefaultToolkit().getScreenSize().height);
      webView.setId(WEBVIEW_ID);
      //webView.setFontSmoothingType(FontSmoothingType.LCD); //Font.loadFont(getClass().getResource("/WK붓글.ttf").toExternalForm(), 20);
      webEngine.setJavaScriptEnabled(true); 
      webEngine.getLoadWorker().stateProperty().addListener(new ChangeListener<State>() {
    	     @Override
    	     public void changed(ObservableValue ov, State oldState, State newState) {
	           if ((newState == Worker.State.SCHEDULED) || (newState == Worker.State.SCHEDULED && browserLocation != webEngine.getLocation())) {
    	        	   		browserLocation = webEngine.getLocation();
    	        	   		System.out.println(browserLocation+webEngine.getTitle()); //NEW URL
    	        	   		
    	        	   		mTextbox.setText(browserLocation);
    	        	   		
    	        	   		//_tab.setText(webEngine.getTitle());
    	        	   		if(webEngine.getTitle()!=null) _tab.setText(webEngine.getTitle());
	        	   		else if(_tab.getText() != "Welcome!")_tab.setText("Unknown");
    	        	   		
    	        	   		webView.setZoom(1);
    	        	   		zoom_rate.setText("x1.0");
    	        	   		
    	        	   		shareURL = webEngine.getLocation();
    	        	   		
    	           } if (newState == Worker.State.SUCCEEDED && browserLocation != webEngine.getLocation()) { //NO else-if, Re-direct URL 처리.
	        	   		browserLocation = webEngine.getLocation();
	        	   		System.out.println("-> "+browserLocation); //NEW URL
	        	   		
	        	   		mTextbox.setText(browserLocation);
	        	   		
	        	   		if(webEngine.getTitle()!=null) _tab.setText(webEngine.getTitle());
	        	   		
	        	   		webView.setZoom(1);
	        	   		zoom_rate.setText("x1.0");
	        	   		
	        	   		shareURL = webEngine.getLocation();
	           }
    	           
    	           if(newState == Worker.State.SUCCEEDED) {
    	        	   		webView.setZoom(1);
    	        	   		zoom_rate.setText("x1.0");
    	           }
    	     }
      }); 
      
      _tab.setOnSelectionChanged(new EventHandler<Event>() {
    	    @Override
    	    public void handle(Event event) {
    	    		System.out.println("TABCHANGED // " + webEngine.getLocation());
    	    		shareURL = webEngine.getLocation();
    	    }
    	  });
      
      System.out.println("Java Version:   " + System.getProperty("java.runtime.version"));
      System.out.println("JavaFX Version: " + System.getProperty("javafx.runtime.version"));
      System.out.println("OS:             " + System.getProperty("os.name") + " / " + System.getProperty("os.arch"));
      System.out.println("User Agent:     " + webView.getEngine().getUserAgent());
      System.out.println("Font Info:      " + Font.getDefault().getName());
      System.out.println("Init Location:  "+webEngine.getLocation());
      
      //---------- WebView AREA ----------
      
      mTextbox.setOnAction((ActionEvent event) -> {
    	  	//if - Enter Key Pressed
    	  	String rt = mTextbox.getText().split("://")[0].equals("http") || mTextbox.getText().split("://")[0].equals("https") ? mTextbox.getText() : "http://"+mTextbox.getText() ;
    	  	webEngine.load(rt);
      });
      
      mTextbox.focusedProperty().addListener(new ChangeListener<Boolean>() {
          @Override
          public void changed(ObservableValue ov, Boolean t, Boolean t1) {
              Platform.runLater(new Runnable() {
                  @Override
                  public void run() {
                      if (mTextbox.isFocused() && !mTextbox.getText().isEmpty()) {
                          mTextbox.selectAll();
                      }
                  }
              });
          }
      });
      
      back.setOnAction((ActionEvent event) -> { 
    	  	webEngine.executeScript("history.back()");
      });
      
      forward.setOnAction((ActionEvent event) -> {
    	  	webEngine.executeScript("history.forward()");
      });
      
      refresh.setOnAction((ActionEvent event) -> {
    	  	webEngine.reload();
      });
      
      zoomIN.setOnAction((ActionEvent event) -> {
    	  	if(webView.getZoom() <= 3.0D) {
    	  		webView.setZoom(webView.getZoom()+0.1);
    	  		zoom_rate.setText("x"+String.format("%.1f",webView.getZoom()));
    	  	}
      });
      
      zoomOUT.setOnAction((ActionEvent event) -> {
    	  	if(webView.getZoom() > 0.3D) {
    	  		webView.setZoom(webView.getZoom()-0.1);
    	  		zoom_rate.setText("x"+String.format("%.1f", webView.getZoom()));
    	  	}
      }); //end of zoom pt.
      
      goHome.setOnAction((ActionEvent event) -> {
    	  	webEngine.load(main_url.toString());
      });
      
      connect.setOnAction((ActionEvent event) -> {
    	  	PopOver popover = getPopover_Connect();
    	  	popover.show(connect);
      });
      

      mTextbox.setAlignment(Pos.CENTER);

      final Pane leftSpacer = new Pane();
      HBox.setHgrow(
              leftSpacer,
              Priority.SOMETIMES
      );
      
      final Pane rightSpacer = new Pane();
      HBox.setHgrow(
              rightSpacer,
              Priority.SOMETIMES
      );
      
      mToolbar.getItems().addAll(back, forward, refresh, goHome, leftSpacer, mTextbox, rightSpacer, zoomIN, zoom_rate, zoomOUT, connect, Member);
      //StackPane stack1 = new StackPane();
      //stack1.getChildren().add(webView);
      
      inBox.getChildren().add(mToolbar);
      inBox.getChildren().add(webView);
      _tab.setContent(inBox);
      
      webEngine.load(BrowserLoc);
      System.out.println("NEWTAB");
      //System.out.println(browserLocation.split(":")[1] +" ==== "+ "//"+main_url.toString().split(":")[1]);
      
      //---------- WebView Area ----------
      //_tab.setStyle("-fx-background-radius: 10 10 0 0, 9 9 0 0, 8 8 0 0; -fx-border-radius: 9 9 0 0, 8 8 0 0;");
	  return _tab;
  }
  
  private ImageView _getImageView(InputStream imgLoc) {
	  ImageView imageView = new ImageView(new Image(imgLoc));
	  imageView.setFitHeight(22);
	  imageView.setFitWidth(22);
	  return imageView;
  }
  
  private boolean connectServer(String ip, int port) throws UnknownHostException, IOException {
	  if(connectStatus == false) {
		  socket = new Socket(ip, port);
		  input_reader = new LiveLinkReader(socket);
		  
		  base_client = new BubbleClient(socket);
		  base_client.start();
		  
		  connectStatus = true;
	  } else System.out.println("이미 연결됨");
	  return true;
  }
  
  private PopOver getPopover_Connect() {
	  PopOver _popover = new PopOver();
	  _popover.setId("popover");
	  VBox vbox = new VBox();
	  vbox.setId("recive_vbox");
	  vbox.setAlignment(Pos.BASELINE_CENTER);
	  vbox.setSpacing(6);
	  
	  TextField ip = new TextField(); //format ONLY 처리 필요...
	  TextField port = new TextField();
	  
	  Button sumbit = new Button("Connect");
	  sumbit.setId("_popover_button");
	  
	  sumbit.setOnAction((ActionEvent event) -> {
		  if(connectStatus == false)
			try {
				connectServer(ip.getText(), Integer.parseInt(port.getText()));
			} catch (NumberFormatException e) {
				System.out.println("sumbit error :wrong format");
				e.printStackTrace();
			} catch (UnknownHostException e) {
	 			e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}
		  // TODO 연결 종료시 처리 및 원상회복 등 try-catch 내 이벤트 이용한 처리 확인.
		  _popover.hide();
	  });
	  
	  if(connectStatus == true) {
		  Label text = new Label("이미 연결되었습니다.");
		  _popover.setContentNode(text);
	  }else {
		  vbox.getChildren().addAll(ip, port, sumbit);
		  _popover.setContentNode(vbox);
	  }
	  _popover.setDetachable(false);
	  _popover.setArrowLocation(ArrowLocation.TOP_RIGHT);
	  /*
	  _popover.setArrowIndent(size);
	  _popover.setArrowSize(size);
	  _popover.setCornerRadius(radius);*/
	  _popover.setCloseButtonEnabled(true);
	  return _popover;
  }
  
  private void sendData() throws IOException {
	  input_reader.sendData(shareURL);
  }
  
  private void getMemberData() throws IOException {
	  input_reader.sendData("memberdata");
  }
  
  public static void reciveDataByPopOver(String URL, String IP) {
	  PopOver _popover = new PopOver();
	  VBox base = new VBox();
	  HBox hbox = new HBox();
	  base.setAlignment(Pos.CENTER);
	  hbox.setAlignment(Pos.CENTER);
	  hbox.setSpacing(10);
	  Label IP_label = new Label("발신자 IP : "+IP);
	  IP_label.setTextAlignment(TextAlignment.CENTER);
	  
	  Label URL_label = new Label(URL);
	  URL_label.setTextAlignment(TextAlignment.CENTER);
	  URL_label.setStyle("-fx-padding : 1.1em 0 1.1em 0;");
	  
	  base.setId("recive_vbox");
	  
	  Button OK = new Button("OK");
	  OK.setId("_popover_button");
	  OK.setOnAction((ActionEvent event) -> {
		 Tab tmp = tabPane.getSelectionModel().getSelectedItem();
    	  	 VBox s = (VBox) tmp.getContent();
    	  	 WebView w = (WebView)s.getChildren().get(1);
    	  	 w.getEngine().load(URL);
    	  	 _popover.hide();
	  });
	  
	  Button Cancel = new Button("Cancel");
	  Cancel.setId("_popover_button");
	  Cancel.setOnAction((ActionEvent event) -> {
		  _popover.hide();
	  }); 
	  
	  hbox.getChildren().addAll(OK, Cancel);
	  base.getChildren().addAll(IP_label, URL_label, hbox);
	  _popover.setContentNode(base);
	  _popover.setArrowLocation(ArrowLocation.BOTTOM_CENTER);
	  _popover.setDetachable(false);
	  _popover.show(BubbleButton);
  }
  
  public static void reciveMemberData(String str) {
	  String tmp = "";
	  PopOver _popover = new PopOver();
	  for(int i = 0; i < str.split(",").length; i++) tmp += str.split(",")[i] + "\n";
	  Label label = new Label("현재 접속자 :\n"+tmp);
	  label.setStyle("-fx-padding : 1.1em");
	  _popover.setArrowLocation(ArrowLocation.TOP_RIGHT);
	  _popover.setDetachable(false);
	  _popover.setContentNode(label);
	  _popover.show(tabPane);
  }
 
} 