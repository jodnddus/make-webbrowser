package mainActivity;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.Socket;
import java.net.UnknownHostException;
import javafx.application.Platform;

public class BubbleClient extends Thread{
	
	Socket socket = null;
    BufferedReader bufferedReader = null;
    InputStreamReader mInputstreamreader = null;
    
   public BubbleClient(Socket inputSocket) {
	  System.out.println("CLIENT CREATED");
	   socket = inputSocket;
   }
   
   @Override
   public void run() {
	   try {
            mInputstreamreader = new InputStreamReader(socket.getInputStream(), "UTF-8");
            bufferedReader = new BufferedReader(mInputstreamreader);
            
            while (true) {
            			String str = bufferedReader.readLine();
            			System.out.println("[client oignal input]"+str);
            			if(str != null) {
            				Platform.runLater(new Runnable() {
            					@Override
								public void run() {
            						System.out.println(str.split("!")[0]);
            						if(str.split("!")[0].equals("command//")) {
            							IdeaBubble.reciveMemberData(str.split("!")[1]);
            						} else IdeaBubble.reciveDataByPopOver(str.split(" ")[0], str.split(" ")[1]);
            					}
            				}); //스레드에서 도형방식사용자대면부를 유도제어하는 유일방도 입네다. 
            			}
            }
        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace(); // TODO 언노운 호스트 연결 시 예외 처리.
        }
   }
	   
}